import type { MetadataRoute } from "next";

export default function robots(): MetadataRoute.Robots {
  return {
    rules: {
      userAgent: "*",
      allow: "/",
    },
    sitemap: "https://fantawalter-app.vercel.app/sitemap.xml",
    host: "https://fantawalter-app.vercel.app",
  };
}
